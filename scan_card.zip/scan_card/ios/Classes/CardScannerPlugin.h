#import <Flutter/Flutter.h>

@interface CardScannerPlugin : NSObject<FlutterPlugin>
@end
