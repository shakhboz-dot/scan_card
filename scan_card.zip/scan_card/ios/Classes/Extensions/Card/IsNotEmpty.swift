extension String {
    var isNotEmpty: Bool {
        return !isEmpty
    }
}
