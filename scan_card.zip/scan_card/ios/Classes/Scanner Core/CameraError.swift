import Foundation

enum CameraError: Error {
    case accessDenied
}
