//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<card_scanner/CardScannerPlugin.h>)
#import <card_scanner/CardScannerPlugin.h>
#else
@import card_scanner;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CardScannerPlugin registerWithRegistrar:[registry registrarForPlugin:@"CardScannerPlugin"]];
}

@end
